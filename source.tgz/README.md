# رحلة الزكاة — المصدر
- `game/` محرّك العالم (main.js, world.js, terrain.js, assets.js, content.js)
- `login.js` شاشة الدخول
- `pages/` قوالب index.html / game.html (نسخة المجلّدات؛ النسخة المسطّحة على GitHub تضيف window.__FLAT=1 وتستبدل assets/ بـ assets__)
- البناء: `npm i` ثم `npx esbuild game/main.js --bundle --minify --outfile=game.bundle.js` و `npx esbuild login.js --bundle --minify --outfile=login.bundle.js`
- الأصول في الجذر بأسماءٍ مسطّحة `assets__<مجلّد>__<ملفّ>`
