// بناءُ العالم: السماء، الأرض، الماء، النبات، السوق، البوّابات، الحيوانات، اللافتات، المحطّات.
import * as THREE from 'three';
import { H, LEN, WID, X0, X1, GATE_X, REGION_CENTER, regionW, fbm, onRoad, buildTerrain, splatMaterial, slopeAt } from './terrain.js';
import { A, texSet, pbr, loadTex, models, scatter, placeOne, loadGLB, cloneSkinned } from './assets.js';
import { STYLE } from './content.js';

const R = (seed => () => { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; })(4242);
const rnd = (a, b) => a + R() * (b - a);
const clamp01 = v => Math.min(1, Math.max(0, v));

export const world = { colliders: [], boxes: [], lights: [], animated: [], signs: [], animals: [], stations: [], gates: [], lanterns: [] };

// ---------- لافتةٌ خشبيّة ----------
export function textCanvas(txt, opts = {}) {
  const c = document.createElement('canvas'); c.width = opts.w || 512; c.height = opts.h || 256; const g = c.getContext('2d');
  if (opts.bg) { g.fillStyle = opts.bg; g.fillRect(0, 0, c.width, c.height); }
  g.fillStyle = opts.color || '#2a1a0c'; g.font = `${opts.weight || 700} ${opts.size || 150}px ${opts.font || 'Lalezar, Changa, sans-serif'}`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.direction = 'rtl';
  if (opts.shadow) { g.shadowColor = opts.shadow; g.shadowBlur = 24; }
  g.fillText(txt, c.width / 2, c.height / 2 + (opts.dy || 0));
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8; return t;
}
function woodSign(x, z, txt, ry, mats) {
  const y = H(x, z); const g = new THREE.Group(); g.position.set(x, y, z); g.rotation.y = ry;
  const post = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.09, 2.0, 8), mats.wood); post.position.y = 1; post.castShadow = true; g.add(post);
  const board = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.8, 0.08), mats.wood); board.position.set(0, 1.75, 0); board.castShadow = true; g.add(board);
  const face = new THREE.Mesh(new THREE.PlaneGeometry(1.4, 0.7), new THREE.MeshStandardMaterial({ map: textCanvas(txt, { bg: '#e9d7b0', size: 170 }), roughness: 0.9 })); face.position.set(0, 1.75, 0.045); g.add(face);
  g.userData = { sign: txt, x, z }; world.signs.push(g.userData); world.colliders.push({ x, z, r: 0.35 });
  return g;
}

// ---------- منزلٌ طينيّ ----------
function adobeHouse(x, z, w, d, h, ry, mats, opt = {}) {
  const g = new THREE.Group(); g.position.set(x, H(x, z) - 0.3, z); g.rotation.y = ry;
  const body = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mats.wall); body.position.y = h / 2; body.castShadow = body.receiveShadow = true; g.add(body);
  // شرفةُ السطح
  const par = new THREE.Mesh(new THREE.BoxGeometry(w + 0.3, 0.5, d + 0.3), mats.wall2); par.position.y = h + 0.1; par.castShadow = true; g.add(par);
  const roof = new THREE.Mesh(new THREE.BoxGeometry(w - 0.2, 0.2, d - 0.2), mats.roof); roof.position.y = h + 0.05; g.add(roof);
  if (opt.dome) { const dome = new THREE.Mesh(new THREE.SphereGeometry(Math.min(w, d) * 0.32, 24, 12, 0, Math.PI * 2, 0, Math.PI / 2), mats.wall2); dome.position.set(0, h + 0.3, 0); dome.castShadow = true; g.add(dome); }
  // بابٌ مقوّس (تجويف داكن) ونوافذ مضيئة
  const door = new THREE.Mesh(new THREE.PlaneGeometry(1.3, 2.3), mats.dark); door.position.set(opt.doorX || 0, 1.15, d / 2 + 0.01); g.add(door);
  const arch = new THREE.Mesh(new THREE.CircleGeometry(0.65, 20, 0, Math.PI), mats.dark); arch.position.set(opt.doorX || 0, 2.3, d / 2 + 0.01); g.add(arch);
  const nWin = Math.max(1, Math.floor(w / 3));
  for (let i = 0; i < nWin; i++) { const wx = -w / 2 + (i + 0.5) * (w / nWin); if (Math.abs(wx - (opt.doorX || 0)) < 1.2) continue; const win = new THREE.Mesh(new THREE.PlaneGeometry(0.6, 0.9), mats.glow); win.position.set(wx, h * 0.62, d / 2 + 0.012); g.add(win); }
  // مظلّةٌ قماشيّة
  if (opt.awning) { const aw = new THREE.Mesh(new THREE.PlaneGeometry(w * 0.7, 1.6), mats.awning); aw.position.set(0, h * 0.5 + 0.9, d / 2 + 0.75); aw.rotation.x = -Math.PI / 2 + 0.35; aw.castShadow = true; g.add(aw); }
  // تصادم: صندوقٌ موجّه → نقرّبه بمستطيلٍ محورٍ بعد الدوران (ry مضاعفُ ٩٠° هنا)
  const sw = Math.abs(Math.cos(ry)) > 0.5 ? w : d, sd = Math.abs(Math.cos(ry)) > 0.5 ? d : w;
  world.boxes.push({ x0: x - sw / 2 - 0.3, x1: x + sw / 2 + 0.3, z0: z - sd / 2 - 0.3, z1: z + sd / 2 + 0.3 });
  return g;
}

// ---------- محطّة ----------
function stationMarker(st, x, z, mats) {
  const y = H(x, z); const g = new THREE.Group(); g.position.set(x, y, z); const style = STYLE[st.t];
  const ped = new THREE.Mesh(new THREE.CylinderGeometry(0.95, 1.1, 0.35, 24), mats.ped); ped.position.y = 0.17; ped.receiveShadow = ped.castShadow = true; g.add(ped);
  const ring = new THREE.Mesh(new THREE.TorusGeometry(0.75, 0.05, 10, 48), new THREE.MeshBasicMaterial({ color: style.ring })); ring.rotation.x = Math.PI / 2; ring.position.y = 0.38; g.add(ring);
  const beam = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.6, 9, 16, 1, true), new THREE.MeshBasicMaterial({ color: style.ring, transparent: true, opacity: 0.16, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide })); beam.position.y = 4.9; g.add(beam);
  const icon = new THREE.Sprite(new THREE.SpriteMaterial({ map: textCanvas(style.icon, { w: 256, h: 256, size: 150, color: '#ffffff', shadow: '#' + style.ring.toString(16).padStart(6, '0') }), transparent: true, depthWrite: false })); icon.scale.set(1.3, 1.3, 1); icon.position.y = 1.9; g.add(icon);
  const label = new THREE.Sprite(new THREE.SpriteMaterial({ map: textCanvas(style.label + ' · ' + st.tag, { w: 512, h: 128, size: 60, color: '#fff3e0', shadow: '#000' }), transparent: true, depthWrite: false })); label.scale.set(3.2, 0.8, 1); label.position.y = 2.9; g.add(label);
  g.userData = { st, x, z, ring, beam, icon, label, done: false, tries: 0 }; world.stations.push(g.userData); world.animated.push(g);
  return g;
}

// ---------- بوّابة ----------
function gate(x, mats, idx) {
  const z = 0; const y = H(x, z); const g = new THREE.Group(); g.position.set(x, y - 0.2, z);
  const pil = new THREE.BoxGeometry(1.6, 7, 1.6);
  for (const s of [-1, 1]) { const p = new THREE.Mesh(pil, mats.stone); p.position.set(0, 3.5, s * 5.2); p.castShadow = p.receiveShadow = true; g.add(p); const cap = new THREE.Mesh(new THREE.BoxGeometry(2.1, 0.5, 2.1), mats.stone2); cap.position.set(0, 7.2, s * 5.2); g.add(cap); }
  const lin = new THREE.Mesh(new THREE.BoxGeometry(1.7, 1.3, 12.4), mats.stone2); lin.position.set(0, 7.9, 0); lin.castShadow = true; g.add(lin);
  const arc = new THREE.Mesh(new THREE.TorusGeometry(4.4, 0.55, 10, 40, Math.PI), mats.stone); arc.rotation.y = Math.PI / 2; arc.position.set(0, 4.2, 0); arc.castShadow = true; g.add(arc);
  const field = new THREE.Mesh(new THREE.PlaneGeometry(8.6, 6.8), new THREE.MeshBasicMaterial({ color: 0xffd27a, transparent: true, opacity: 0.22, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide })); field.rotation.y = Math.PI / 2; field.position.set(0, 3.4, 0); g.add(field);
  const banner = new THREE.Sprite(new THREE.SpriteMaterial({ map: textCanvas('البوّابة ' + ['الأولى', 'الثانية'][idx], { w: 512, h: 128, size: 64, color: '#fff3e0', shadow: '#000' }), transparent: true, depthWrite: false })); banner.scale.set(4.5, 1.1, 1); banner.position.y = 9.2; g.add(banner);
  const wall = { x0: x - 0.9, x1: x + 0.9, z0: -4.4, z1: 4.4, gate: true }; world.boxes.push(wall);
  world.boxes.push({ x0: x - 1, x1: x + 1, z0: -48, z1: -4.4 }, { x0: x - 1, x1: x + 1, z0: 4.4, z1: 48 });
  g.userData = { x, field, wall, open: false, idx }; world.gates.push(g.userData); world.animated.push(g);
  return g;
}

// ---------- الحيوانات ----------
async function herd(scene, kind, tag, spots, mixers, scale) {
  const g = await loadGLB(A('anim2/' + kind + '.glb')); const idle = g.animations.find(a => /idle/i.test(a.name)) || g.animations[0];
  for (const s of spots) {
    const o = cloneSkinned(g.scene); o.traverse(m => { if (m.isMesh) { m.castShadow = true; m.frustumCulled = false; if (m.material) { m.material.roughness = 0.85; } } });
    const bb = new THREE.Box3().setFromObject(g.scene); const h = bb.max.y - bb.min.y || 1; const sc = scale / h; o.scale.setScalar(sc); o.position.set(s[0], H(s[0], s[1]) - bb.min.y * sc, s[1]); o.rotation.y = s[2] || rnd(0, 6.28);
    if (idle) { const mx = new THREE.AnimationMixer(o); const act = mx.clipAction(idle); act.time = rnd(0, idle.duration); act.play(); mixers.push(mx); }
    scene.add(o); world.animals.push({ tag, x: s[0], z: s[1], o }); world.colliders.push({ x: s[0], z: s[1], r: 0.9 });
  }
}

// ---------- عشبٌ كثيف: بطاقاتٌ متقاطعة مثيليّة تتمايل مع الريح ----------
export function grassField(transforms, tex, opts = {}) {
  // ثلاثُ مستطيلاتٍ متقاطعة، المحورُ عند القاعدة، القِيَم العموديّة للإضاءة كالأرض
  const quads = []; const w = 1.0, h = 0.75;
  for (let k = 0; k < 3; k++) { const a = k * Math.PI / 3; const c = Math.cos(a), sn = Math.sin(a); quads.push([[-w / 2 * c, 0, -w / 2 * sn], [w / 2 * c, 0, w / 2 * sn], [w / 2 * c, h, w / 2 * sn], [-w / 2 * c, h, -w / 2 * sn]]); }
  const pos = [], uv = [], nor = [], idx = [];
  quads.forEach((q, k) => { const b = k * 4; q.forEach((v, i) => { pos.push(...v); uv.push(i === 1 || i === 2 ? 1 : 0, i >= 2 ? 1 : 0); nor.push(0, 1, 0); }); idx.push(b, b + 1, b + 2, b, b + 2, b + 3); });
  const geo = new THREE.InstancedBufferGeometry(); geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); geo.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2)); geo.setAttribute('normal', new THREE.Float32BufferAttribute(nor, 3)); geo.setIndex(idx);
  const n = transforms.length; const cell = new Float32Array(n); for (let i = 0; i < n; i++) cell[i] = Math.floor(R() * 4);
  geo.setAttribute('cell', new THREE.InstancedBufferAttribute(cell, 1));
  const mat = new THREE.MeshStandardMaterial({ map: tex, alphaTest: 0.45, side: THREE.DoubleSide, roughness: 0.95, metalness: 0 });
  mat.onBeforeCompile = sh => {
    sh.uniforms.uTime = { value: 0 }; mat.userData.sh = sh;
    sh.vertexShader = sh.vertexShader
      .replace('#include <common>', '#include <common>\nattribute float cell; uniform float uTime;')
      .replace('#include <uv_vertex>', '#include <uv_vertex>\nvMapUv.x = (vMapUv.x + cell) / 4.0;')
      .replace('#include <begin_vertex>', '#include <begin_vertex>\n{ vec4 wp = instanceMatrix * vec4(position, 1.0); float sway = sin(uTime * 1.6 + wp.x * 0.35 + wp.z * 0.21) * 0.12 + sin(uTime * 3.1 + wp.z * 0.9) * 0.04; transformed.x += sway * uv.y; transformed.z += sway * 0.5 * uv.y; }');
  };
  mat.customProgramCacheKey = () => 'grasscards';
  const im = new THREE.InstancedMesh(geo, mat, n); im.castShadow = false; im.receiveShadow = true;
  const mtx = new THREE.Matrix4(), q = new THREE.Quaternion(), p = new THREE.Vector3(), sc = new THREE.Vector3(); const col = new THREE.Color();
  transforms.forEach((t, i) => { p.set(t.x, t.y - 0.03, t.z); q.setFromEuler(new THREE.Euler(0, t.ry, 0)); sc.set(t.s, t.s * (0.8 + R() * 0.5), t.s); mtx.compose(p, q, sc); im.setMatrixAt(i, mtx); col.setHSL(0.23 + (t.hue || 0) + (R() - 0.5) * 0.03, 0.6 + (R() - 0.5) * 0.2, 0.5 + (R() - 0.5) * 0.14); im.setColorAt(i, col); });
  im.instanceMatrix.needsUpdate = true; im.instanceColor.needsUpdate = true; im.computeBoundingSphere(); im.frustumCulled = true;
  return im;
}

// ---------- العالم كلّه ----------
export async function buildWorld(scene, topic, quality) {
  // خامات
  const tex = {
    grass: texSet('leafy_grass'), dry: texSet('gravelly_sand'), sand: texSet('mud_cracked_dry_03'), cob: texSet('cobblestone_floor_08'),
  };
  const terrainMat = splatMaterial({ d0: tex.grass.d, n0: tex.grass.n, d1: tex.dry.d, n1: tex.dry.n, d2: tex.sand.d, n2: tex.sand.n, d3: tex.cob.d, n3: tex.cob.n });
  const terrain = buildTerrain(terrainMat); scene.add(terrain);
  const mats = {
    wood: pbr('wood_planks_grey', 1), wall: pbr('plastered_wall_02', 2, { color: 0xf3e2c6 }), wall2: pbr('clay_plaster', 2, { color: 0xe9cfa6 }), roof: pbr('mud_cracked_dry_03', 2),
    stone: pbr('red_sandstone_wall', 2), stone2: pbr('plaster_stone_wall_01', 2), ped: pbr('red_sandstone_pavement', 1),
    dark: new THREE.MeshStandardMaterial({ color: 0x1a120c, roughness: 1 }),
    glow: new THREE.MeshStandardMaterial({ color: 0xffb060, emissive: 0xffa040, emissiveIntensity: 1.6, roughness: 0.6 }),
    awning: new THREE.MeshStandardMaterial({ map: (() => { const c = document.createElement('canvas'); c.width = 256; c.height = 64; const g = c.getContext('2d'); for (let i = 0; i < 8; i++) { g.fillStyle = i % 2 ? '#c9483a' : '#f2e6d0'; g.fillRect(i * 32, 0, 32, 64); } const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(2, 1); return t; })(), roughness: 0.9, side: THREE.DoubleSide }),
  };
  mats.wall.map.repeat.set(2, 1); mats.wall.normalMap.repeat.set(2, 1);

  // ماءُ الوادي
  const wy = H(30, 16) - 0.55;
  const water = new THREE.Mesh(new THREE.CircleGeometry(15, 48), new THREE.MeshPhysicalMaterial({ color: 0x246a7d, metalness: 0.1, roughness: 0.07, normalMap: loadTex(A('tex/coast_sand_01_nor_gl.webp'), false, 6), normalScale: new THREE.Vector2(0.25, 0.25), envMapIntensity: 1.5, clearcoat: 1, clearcoatRoughness: 0.05, transparent: true, opacity: 0.92 }));
  water.rotation.x = -Math.PI / 2; water.position.set(8, wy, 16); scene.add(water); world.water = water; world.waterY = wy;

  // ---------- نثرُ النبات والصخور ----------
  const T = { grass: [], grass2: [], shrub1: [], shrub2: [], shrub3: [], bush: [], rock2: [], rock3: [], rock5: [], boulder: [], sandrocks: [], palmA: [], palmB: [], island: [], quiver: [], trunk: [], stump: [] };
  const okSpot = (x, z, keepRoad = 2.5) => Math.abs(z) < WID * 0.42 && x > X0 + 6 && x < X1 - 6 && onRoad(x, z) < 0.15 && slopeAt(x, z) < 0.75 && Math.hypot(x - 8, z - 16) > 15.5 && !(x > 56 && x < 108 && Math.abs(z) < 24) && Math.abs(x - GATE_X[0]) > 4 && Math.abs(x - GATE_X[1]) > 4;
  const grassN = quality.grass;
  for (let i = 0; i < grassN; i++) { const x = rnd(X0, X1), z = rnd(-40, 40); if (!okSpot(x, z)) continue; const w = regionW(x); const p = w[0] * 0.9 + w[1] * 0.35 + w[2] * 0.08; if (R() > p) continue; (R() < 0.6 ? T.grass : T.grass2).push({ x, y: H(x, z), z, ry: rnd(0, 6.28), s: rnd(0.8, 1.4) }); }

  for (let i = 0; i < 90; i++) { const x = rnd(X0, X1), z = rnd(-40, 40); if (!okSpot(x, z)) continue; const w = regionW(x); if (R() > w[0] * 0.8 + w[1] * 0.7 + w[2] * 0.25) continue; [T.shrub1, T.shrub2, T.shrub3, T.bush][Math.floor(R() * 4)].push({ x, y: H(x, z), z, ry: rnd(0, 6.28), s: rnd(0.9, 1.5) }); }
  for (let i = 0; i < 70; i++) { const x = rnd(X0, X1), z = rnd(-42, 42); if (!okSpot(x, z)) continue; if (Math.abs(z) < 12 && R() < 0.6) continue; const k = [T.rock2, T.rock3, T.rock5, T.boulder, T.sandrocks][Math.floor(R() * 5)]; const s = k === T.boulder ? rnd(0.6, 1.4) : rnd(0.8, 1.8); k.push({ x, y: H(x, z) - 0.15, z, ry: rnd(0, 6.28), s }); world.colliders.push({ x, z, r: (k === T.sandrocks ? 1.4 : 1.0) * s }); }
  // نخيلٌ حول البركة وفي الوادي والسوق
  for (let i = 0; i < 24; i++) { const a = rnd(0, 6.28), d = rnd(16.5, 24); const x = 8 + Math.cos(a) * d, z = 16 + Math.sin(a) * d * 0.8; if (Math.abs(z) < 7.5 || Math.abs(z) > 40 || !okSpot(x, z)) continue; (R() < 0.5 ? T.palmA : T.palmB).push({ x, y: H(x, z) - 0.2, z, ry: rnd(0, 6.28), s: rnd(0.5, 0.72) }); world.colliders.push({ x, z, r: 0.5 }); }
  for (let i = 0; i < 26; i++) { const x = rnd(-38, X1 - 8), z = rnd(-42, 42); if (!okSpot(x, z) || Math.abs(z) < 9) continue; const w = regionW(x); if (R() > w[1] * 0.35 + w[2] * 0.55) continue; (R() < 0.5 ? T.palmA : T.palmB).push({ x, y: H(x, z) - 0.2, z, ry: rnd(0, 6.28), s: rnd(0.45, 0.7) }); world.colliders.push({ x, z, r: 0.5 }); }
  // أشجارُ المرعى
  for (let i = 0; i < 28; i++) { const x = rnd(X0 + 8, GATE_X[0] - 6), z = rnd(-42, 42); if (!okSpot(x, z) || Math.abs(z) < 9) continue; if (R() < 0.35) { T.island.push({ x, y: H(x, z) - 0.1, z, ry: rnd(0, 6.28), s: rnd(1.1, 1.6) }); world.colliders.push({ x, z, r: 0.7 }); } else { T.quiver.push({ x, y: H(x, z) - 0.1, z, ry: rnd(0, 6.28), s: rnd(0.9, 1.4) }); world.colliders.push({ x, z, r: 0.5 }); } }
  for (let i = 0; i < 8; i++) { const x = rnd(X0 + 10, X1 - 10), z = rnd(-40, 40); if (!okSpot(x, z) || Math.abs(z) < 9) continue; (R() < 0.5 ? T.trunk : T.stump).push({ x, y: H(x, z) - 0.05, z, ry: rnd(0, 6.28), s: 1 }); world.colliders.push({ x, z, r: 0.8 }); }
  const map = { grass: 'grass_medium_01', grass2: 'grass_medium_02', shrub1: 'shrub_01', shrub2: 'shrub_02', shrub3: 'shrub_03', bush: 'wild_rooibos_bush', rock2: 'namaqualand_boulder_02', rock3: 'namaqualand_boulder_03', rock5: 'namaqualand_boulder_05', boulder: 'boulder_01', sandrocks: 'sand_rocks_small_01', palmA: 'palm_a', palmB: 'palm_b', island: 'island_tree_01', quiver: 'quiver_tree_01', trunk: 'dead_tree_trunk', stump: 'tree_stump_01' };
  for (const k in map) { const g = scatter(map[k], T[k], { shadow: !(k === 'grass' || k === 'grass2') }); if (g) scene.add(g); }

  // ---------- المرعى: القطعان واللافتات ----------
  const mixers = world.mixers = [];
  await herd(scene, 'Cow', 'بقر', [[-86, 11, 0.4], [-88, 14, 1.2], [-83, 15, -0.4], [-90, 10, 2.2]], mixers, 1.5);
  await herd(scene, 'Sheep', 'غنم', [[-74, -11, 0.2], [-76, -14, 1.4], [-72, -14, -1], [-78, -10, 2.6], [-70, -12, 0.8]], mixers, 0.9);
  await herd(scene, 'Horse', 'خيل', [[-100, -12, 0.6], [-103, -9, 1.9], [-97, -10, -0.5]], mixers, 1.7);
  { const cam = await loadGLB(A('anim2/Camel.glb')); for (const s of [[-62, 13, 0.3], [-66, 16, 1.4], [-60, 17, -0.8]]) { const o = cam.scene.clone(); const bb = new THREE.Box3().setFromObject(cam.scene); const sc = 2.1 / (bb.max.y - bb.min.y); o.scale.setScalar(sc); o.position.set(s[0], H(s[0], s[1]) - bb.min.y * sc, s[1]); o.rotation.y = s[2]; o.traverse(m => { if (m.isMesh) { m.castShadow = true; m.material.roughness = 0.85; } }); scene.add(o); world.animals.push({ tag: 'إبل', x: s[0], z: s[1], o }); world.colliders.push({ x: s[0], z: s[1], r: 1 }); } }
  const R0 = topic.regions;
  const signSpots = [[[-95, 6], [-64, -7], [-52, 8]], [[-30, -9], [-4, -13], [22, 9]], [[54, -8], [64, 9], [96, -9]]];
  R0.forEach((rg, ri) => rg.signs.forEach((s, i) => { const [x, z] = signSpots[ri][i]; scene.add(woodSign(x, z, s, Math.atan2(0 - x, 0 - z) + Math.PI, mats)); }));

  // ---------- الوادي: حقلٌ ----------
  { const rows = []; for (let r = 0; r < 7; r++) for (let c = 0; c < 26; c++) { const x = -34 + c * 1.1 + (r % 2) * 0.5, z = -22 + r * 1.5; rows.push({ x, y: H(x, z), z, ry: rnd(0, 6.28), s: rnd(1.6, 2.2) }); } const g = scatter('grass_bermuda_01', rows, { shadow: false }); if (g) { g.traverse(m => { if (m.isInstancedMesh) { m.material = m.material.clone(); m.material.color.set(0xd9b451); } }); scene.add(g); } }

  // ---------- السوق ----------
  const houses = [
    [60, -15, 8, 7, 4.2, 0, { awning: true, doorX: 1.5 }], [70, -16, 7, 7, 5, 0, { dome: true }], [80, -15, 9, 7, 4.4, 0, { awning: true }], [90, -16, 7, 7, 5.6, 0, { dome: true, doorX: -1.2 }], [100, -15, 8, 7, 4.2, 0, { awning: true }],
    [60, 15, 8, 7, 4.6, Math.PI, { awning: true }], [70, 16, 7, 7, 5.2, Math.PI, { dome: true, doorX: 1 }], [80, 15, 9, 7, 4.2, Math.PI, { awning: true }], [90, 16, 7, 7, 5.8, Math.PI, { dome: true }], [100, 15, 8, 7, 4.4, Math.PI, { awning: true, doorX: -1.5 }],
    [111, -6, 7, 9, 6.2, Math.PI / 2, { dome: true }], [111, 6, 7, 9, 6.2, Math.PI / 2, { dome: true }],
  ];
  for (const h of houses) scene.add(adobeHouse(...h.slice(0, 6), mats, h[6]));
  // أدواتُ السوق
  const props = [['wooden_crate_01', 64, -10.5], ['wooden_crate_02', 65.2, -10.2], ['wooden_barrels_01', 75, 10.5], ['ceramic_pot', 84, -10.5], ['ceramic_vase_01', 85, -10.2], ['ceramic_vase_02', 85.8, -10.8], ['brass_pot_01', 94, 10.6], ['planter_pot_clay', 96, 10.4], ['potted_plant_01', 57, 10.5], ['painted_wooden_bench', 76, -10.8], ['CoffeeCart_01', 87, 10.8], ['wooden_crate_01', 104, 10.6], ['wooden_barrels_01', 103, -10.5], ['ceramic_pot', 68, 10.5]];
  for (const [n, x, z] of props) { const g = placeOne(n, x, H(x, z) - 0.05, z, rnd(0, 6.28), 1); if (g) { scene.add(g); world.colliders.push({ x, z, r: (models[n]?.r || 0.6) }); } }
  // فوانيس على أعمدة
  const lanternSpots = [[62, -9], [74, 9], [86, -9], [98, 9], [56, 0.001], [108, -0.001]];
  for (const [x, z] of lanternSpots) { const y = H(x, z); const post = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.1, 3.2, 8), mats.wood); post.position.set(x, y + 1.6, z); post.castShadow = true; scene.add(post); const arm = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.08, 0.08), mats.wood); arm.position.set(x + 0.4, y + 3.1, z); scene.add(arm); const l = placeOne('wooden_lantern_01', x + 0.75, y + 2.35, z, 0, 0.9); if (l) { scene.add(l); l.traverse(m => { if (m.isInstancedMesh) { m.material = m.material.clone(); m.material.emissive = new THREE.Color(0xff9a3c); m.material.emissiveIntensity = 0.9; } }); } world.lanterns.push({ x: x + 0.75, y: y + 2.6, z }); world.colliders.push({ x, z, r: 0.25 }); }
  // منصّةُ الختام
  { const x = 118, z = 0; const y = H(x, z); const pod = new THREE.Mesh(new THREE.CylinderGeometry(3.2, 3.4, 0.5, 40), mats.ped); pod.position.set(x, y + 0.25, z); pod.receiveShadow = pod.castShadow = true; scene.add(pod); const ring = new THREE.Mesh(new THREE.TorusGeometry(3.0, 0.04, 8, 80), new THREE.MeshBasicMaterial({ color: 0xffd27a })); ring.rotation.x = Math.PI / 2; ring.position.set(x, y + 0.51, z); scene.add(ring); world.finish = { x, z, y: y + 0.5, ring }; }

  // ---------- المحطّات والبوّابات ----------
  const stSpots = [[[-92, 3.5], [-80, -4], [-68, 4], [-56, -4]], [[-26, 4], [-12, -4], [6, 4], [24, -4]], [[52, 4], [70, -4.5], [86, 4.5], [102, -4]]];
  R0.forEach((rg, ri) => rg.stations.forEach((st, si) => { const [x, z] = stSpots[ri][si]; const m = stationMarker({ ...st, region: ri, index: si }, x, z, mats); scene.add(m); }));
  GATE_X.forEach((gx, i) => scene.add(gate(gx, mats, i)));
  // حارسٌ عند كلّ بوّابة (روبوت Vanguard)
  const guardModel = await loadGLB(A('chars/vanguard.glb')); const idleG = (await loadGLB(A('anim/Looking_Around.glb'))).animations[0];
  world.guards = [];
  GATE_X.forEach((gx, i) => { const o = cloneSkinned(guardModel.scene); o.traverse(m => { if (m.isMesh) { m.castShadow = true; m.frustumCulled = false; m.material = m.material.clone(); m.material.emissive = new THREE.Color(0xffd166); m.material.emissiveIntensity = (m.name || '').toLowerCase().includes('visor') ? 2 : 0; } }); let top = 0; const p = new THREE.Vector3(); o.updateMatrixWorld(true); o.traverse(b => { if (b.isBone) { b.getWorldPosition(p); top = Math.max(top, p.y); } }); o.scale.setScalar(1.85 / (top || 1.8)); const gz = 6.8; o.position.set(gx - 2.2, H(gx - 2.2, gz), gz); o.rotation.y = Math.PI * 0.75; scene.add(o); const mx = new THREE.AnimationMixer(o); mx.clipAction(idleG).play(); mixers.push(mx); world.guards.push({ x: gx - 2.2, z: gz, o, gate: world.gates[i], region: i }); world.colliders.push({ x: gx - 2.2, z: gz, r: 0.7 }); });

  // ---------- جسيمات: غبارٌ ذهبيّ ----------
  const n = quality.dust, pos = new Float32Array(n * 3); for (let i = 0; i < n; i++) { pos[i * 3] = rnd(-30, 30); pos[i * 3 + 1] = rnd(0.3, 6); pos[i * 3 + 2] = rnd(-30, 30); }
  const dust = new THREE.Points(new THREE.BufferGeometry().setAttribute('position', new THREE.BufferAttribute(pos, 3)), new THREE.PointsMaterial({ map: loadTex(A('fx/dust.png')), color: 0xffd9a0, size: 0.35, transparent: true, opacity: 0.55, depthWrite: false, blending: THREE.AdditiveBlending, sizeAttenuation: true }));
  scene.add(dust); world.dust = dust;
  return { terrain, mats };
}
