// تحميلُ الأصول: مسارٌ مسطّحٌ لرفع GitHub، وسماءٌ HDR من صورتين PNG.
import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import * as SkeletonUtils from 'three/examples/jsm/utils/SkeletonUtils.js';

export const A = p => (window.__FLAT ? 'assets__' + p.replace(/\//g, '__') : 'assets/' + p);
export const manager = new THREE.LoadingManager();
const gltf = new GLTFLoader(manager), texL = new THREE.TextureLoader(manager), imgL = new THREE.ImageLoader(manager);
export const loadGLB = u => new Promise((res, rej) => gltf.load(u, res, undefined, rej));
export const loadImg = u => new Promise((res, rej) => imgL.load(u, res, undefined, rej));
export function loadTex(u, srgb = false, rep = 1) { const t = texL.load(u); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(rep, rep); if (srgb) t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8; return t; }
export function texSet(name, rep = 1) { return { d: loadTex(A('tex/' + name + '_diff.webp'), true, rep), n: loadTex(A('tex/' + name + '_nor_gl.webp'), false, rep), a: loadTex(A('tex/' + name + '_arm.webp'), false, rep) }; }
export function pbr(name, rep = 1, extra = {}) { const s = texSet(name, rep); return new THREE.MeshStandardMaterial({ map: s.d, normalMap: s.n, aoMap: s.a, roughnessMap: s.a, metalnessMap: s.a, roughness: 1, metalness: 1, ...extra }); }

export async function loadSkyHDR() {
  const [rgb, e] = await Promise.all([loadImg(A('env/sky_rgb.png')), loadImg(A('env/sky_e.png'))]);
  const w = rgb.width, h = rgb.height; const c = document.createElement('canvas'); c.width = w; c.height = h; const g = c.getContext('2d', { willReadFrequently: true });
  g.drawImage(rgb, 0, 0); const P = g.getImageData(0, 0, w, h).data; g.drawImage(e, 0, 0); const E = g.getImageData(0, 0, w, h).data;
  const out = new Uint16Array(w * h * 4); const f16 = THREE.DataUtils.toHalfFloat;
  for (let i = 0, n = w * h; i < n; i++) { const ex = E[i * 4]; const s = ex ? Math.min(Math.pow(2, ex - 136), 200) : 0; const j = i * 4; out[j] = f16(P[j] * s); out[j + 1] = f16(P[j + 1] * s); out[j + 2] = f16(P[j + 2] * s); out[j + 3] = f16(1); }
  const t = new THREE.DataTexture(out, w, h, THREE.RGBAFormat, THREE.HalfFloatType); t.flipY = true; t.colorSpace = THREE.LinearSRGBColorSpace; t.magFilter = t.minFilter = THREE.LinearFilter; t.generateMipmaps = false; t.needsUpdate = true; return t;
}

// ---------- نماذجُ Poly Haven: كلُّ نموذجٍ قائمةُ (هندسة، خامة) ----------
export const models = {};
export async function loadModels(names) {
  await Promise.all(names.map(async n => {
    const g = await loadGLB(A('ph/' + n + '.glb')); const parts = []; g.scene.updateMatrixWorld(true);
    g.scene.traverse(o => { if (o.isMesh) { const geo = o.geometry.clone(); geo.applyMatrix4(o.matrixWorld); const m = o.material; m.side = m.transparent || m.alphaTest > 0 ? THREE.DoubleSide : THREE.FrontSide; if (m.transparent) { m.transparent = false; m.alphaTest = 0.5; m.depthWrite = true; } parts.push({ geo, mat: m }); } });
    const bb = new THREE.Box3(); parts.forEach(p => { p.geo.computeBoundingBox(); bb.union(p.geo.boundingBox); });
    models[n] = { parts, bb, h: bb.max.y - bb.min.y, r: Math.max(bb.max.x - bb.min.x, bb.max.z - bb.min.z) / 2 };
  }));
}
// نثرٌ مثيليّ: transforms = [{x,y,z,ry,s}]
// النثرُ يُقسَّم إلى رقعٍ (٤٠م) لكلٍّ منها كرةُ إحاطةٍ حتى يعمل قصُّ الرؤية
export function scatter(name, transforms, opts = {}) {
  const M = models[name]; if (!M || !transforms.length) return null;
  const grp = new THREE.Group(); grp.name = 'scatter:' + name; const mtx = new THREE.Matrix4(), q = new THREE.Quaternion(), p = new THREE.Vector3(), s = new THREE.Vector3();
  const cells = new Map(); for (const t of transforms) { const k = Math.floor(t.x / 40) + ':' + Math.floor(t.z / 40); if (!cells.has(k)) cells.set(k, []); cells.get(k).push(t); }
  for (const list of cells.values()) for (const part of M.parts) {
    const im = new THREE.InstancedMesh(part.geo, part.mat, list.length); im.castShadow = opts.shadow !== false; im.receiveShadow = true;
    list.forEach((t, i) => { p.set(t.x, t.y - M.bb.min.y * (t.s || 1) + (opts.sink || 0), t.z); q.setFromEuler(new THREE.Euler(0, t.ry || 0, 0)); s.setScalar(t.s || 1); mtx.compose(p, q, s); im.setMatrixAt(i, mtx); });
    im.instanceMatrix.needsUpdate = true; im.computeBoundingSphere(); im.frustumCulled = true; grp.add(im);
  }
  return grp;
}
export function placeOne(name, x, y, z, ry = 0, s = 1) { return scatter(name, [{ x, y, z, ry, s }]); }

// ---------- الروبوت ----------
export function robotHeight(o) { o.updateMatrixWorld(true); let top = 0; const p = new THREE.Vector3(); o.traverse(b => { if (b.isBone) { b.getWorldPosition(p); top = Math.max(top, p.y); } }); return top || 1.7; }
export function styleRobot(root, def) {
  root.traverse(o => {
    if (!o.isMesh) return; o.castShadow = true; o.frustumCulled = false; const n = (o.material.name || '').toLowerCase();
    if (def.model === 'vanguard') { const m = o.material.clone(); o.material = m; m.envMapIntensity = 1; m.roughness = 0.55; m.metalness = 0.3; if ((o.name || '').toLowerCase().includes('visor')) { m.emissive = new THREE.Color(def.accent); m.emissiveIntensity = 2; } return; }
    o.material = n.includes('joint')
      ? new THREE.MeshStandardMaterial({ color: def.joints, metalness: 0.85, roughness: 0.35, emissive: new THREE.Color(def.accent), emissiveIntensity: 1.1 })
      : new THREE.MeshPhysicalMaterial({ color: def.body, metalness: 0.05, roughness: 0.32, clearcoat: 0.8, clearcoatRoughness: 0.15, envMapIntensity: 0.8 });
  });
}
export const cloneSkinned = o => SkeletonUtils.clone(o);
