// رحلة الزكاة — العالم: المحرّك، اللاعب، التحكّم، المحطّات، الواجهة.
import * as THREE from 'three';
import { TOPICS, STYLE } from './content.js';
import { H, X0, X1, WID, GATE_X, START_X, regionOf, regionW } from './terrain.js';
import { A, manager, loadGLB, loadSkyHDR, loadModels, robotHeight, styleRobot, loadTex } from './assets.js';
import { buildWorld, world, textCanvas } from './world.js';

const $ = id => document.getElementById(id);
const isTouch = matchMedia('(pointer:coarse)').matches;
const topic = TOPICS[new URLSearchParams(location.search).get('topic') || 'zakat'] || TOPICS.zakat;
const AR = n => String(n).replace(/\d/g, d => '٠١٢٣٤٥٦٧٨٩'[d]);
let player = null; try { player = JSON.parse(localStorage.getItem('zakat.player') || 'null'); } catch (e) { }
if (!player) { location.replace('index.html'); }
const ROBOT_DEFS = { noor: { model: 'ybot', accent: 0x35d6ff, body: 0xdfe3e8, joints: 0x1c2026 }, shihab: { model: 'xbot', accent: 0xff7a1a, body: 0xe6e1d6, joints: 0x23201c }, haris: { model: 'vanguard', accent: 0xffd166 }, zumurrud: { model: 'xbot', accent: 0x3cff9a, body: 0x2a2f38, joints: 0x0f1216 } };
const rdef = ROBOT_DEFS[player?.robot] || ROBOT_DEFS.noor;
const quality = isTouch ? { dpr: 1.25, shadow: 1024, grass: 380, dust: 220 } : { dpr: 1.5, shadow: 2048, grass: 750, dust: 420 };

// ---------- المحرّك ----------
const canvas = $('c');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 0.66; renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
const DPR = Math.min(devicePixelRatio || 1, quality.dpr); renderer.setPixelRatio(DPR);
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(50, 1, 0.1, 500);
function resize() { renderer.setSize(innerWidth, innerHeight, false); camera.aspect = innerWidth / innerHeight; camera.fov = innerHeight > innerWidth ? 62 : 50; camera.updateProjectionMatrix(); }
addEventListener('resize', resize);

const SUN_AZ = 0.628, SUN_EL = 0.22, SKY_ROT = 0.314;
const sunDir = new THREE.Vector3(Math.cos(SUN_AZ + SKY_ROT) * Math.cos(SUN_EL), Math.sin(SUN_EL) + 0.12, Math.sin(SUN_AZ + SKY_ROT) * Math.cos(SUN_EL)).normalize();
const sun = new THREE.DirectionalLight(0xffc890, 3.0); sun.castShadow = true; sun.shadow.mapSize.set(quality.shadow, quality.shadow);
Object.assign(sun.shadow.camera, { left: -26, right: 26, top: 26, bottom: -26, near: 1, far: 120 }); sun.shadow.bias = -0.0005; sun.shadow.normalBias = 0.03;
scene.add(sun); scene.add(sun.target);
scene.add(new THREE.HemisphereLight(0xffe0c0, 0x4a3a2a, 0.45));
const fill = new THREE.DirectionalLight(0xffb070, 0.6); fill.position.set(-30, 20, 40); scene.add(fill);
const lanternLights = []; for (let i = 0; i < 4; i++) { const l = new THREE.PointLight(0xff9a3c, 0, 14, 1.8); scene.add(l); lanternLights.push(l); }

// ---------- التحميل ----------
const bar = $('bar'), ltext = $('ltext');
manager.onProgress = (u, l, t) => { bar.style.width = Math.round(100 * l / t) + '%'; };
const clips = {}; let hero, mixer, actions = {}, current = null;
const P = { x: START_X, z: 0, y: 0, vy: 0, yaw: Math.PI / 2, speed: 0, grounded: true, jumping: false };
const cam = { yaw: -Math.PI / 2, pitch: 0.32, dist: 6.4, auto: true };
{ const q = new URLSearchParams(location.search); if (q.get('x')) { P.x = +q.get('x'); P.z = +(q.get('z') || 0); } }
const heroPos = new THREE.Vector3();

async function boot() {
  const env = await loadSkyHDR(); env.mapping = THREE.EquirectangularReflectionMapping; scene.environment = env; scene.background = env;
  scene.backgroundRotation.set(0, SKY_ROT, 0); scene.environmentRotation.set(0, SKY_ROT, 0); scene.environmentIntensity = 0.65; scene.backgroundIntensity = 1;
  scene.fog = new THREE.FogExp2(0xd7a479, 0.0075);
  ltext.textContent = 'تُنحَت الأرض…';
  await loadModels(['grass_medium_01', 'grass_medium_02', 'grass_bermuda_01', 'shrub_01', 'shrub_02', 'shrub_03', 'wild_rooibos_bush', 'namaqualand_boulder_02', 'namaqualand_boulder_03', 'namaqualand_boulder_05', 'boulder_01', 'sand_rocks_small_01', 'palm_a', 'palm_b', 'island_tree_01', 'quiver_tree_01', 'dead_tree_trunk', 'tree_stump_01', 'wooden_crate_01', 'wooden_crate_02', 'wooden_barrels_01', 'ceramic_pot', 'ceramic_vase_01', 'ceramic_vase_02', 'brass_pot_01', 'planter_pot_clay', 'potted_plant_01', 'painted_wooden_bench', 'CoffeeCart_01', 'wooden_lantern_01']);
  ltext.textContent = 'تُزرَع النخيل…';
  await buildWorld(scene, topic, quality);
  ltext.textContent = 'يستيقظ روبوتك…';
  const [g, ...an] = await Promise.all([loadGLB(A('chars/' + rdef.model + '.glb')), ...['Idle', 'Walking', 'Running', 'Jump', 'Victory', 'Defeat', 'Hip_Hop_Dancing', 'Waving'].map(c => loadGLB(A('anim/' + c + '.glb')))]);
  ['Idle', 'Walking', 'Running', 'Jump', 'Victory', 'Defeat', 'Hip_Hop_Dancing', 'Waving'].forEach((c, i) => { clips[c] = an[i].animations[0]; });
  hero = g.scene; const h = robotHeight(hero); hero.scale.setScalar(1.75 / h); styleRobot(hero, rdef); scene.add(hero);
  mixer = new THREE.AnimationMixer(hero); for (const c in clips) { actions[c] = mixer.clipAction(clips[c]); }
  actions.Jump.setLoop(THREE.LoopOnce); actions.Jump.clampWhenFinished = true; actions.Victory.setLoop(THREE.LoopOnce); actions.Defeat.setLoop(THREE.LoopOnce); actions.Waving.setLoop(THREE.LoopOnce);
  play('Idle');
  buildHUD(); setupInput(); resize();
  await new Promise(res => { if (!manager.isLoading) return res(); manager.onLoad = res; setTimeout(res, 9000); });
  renderer.compile(scene, camera);
  $('loader').classList.add('hide'); toast(`أهلًا يا ${player.name} — امشِ إلى المحطّة الأولى`, 4200);
  renderer.setAnimationLoop(loop); window.__ready = 1; window.__world = world; window.__dbg2 = () => ({ grassCount: world.grass.count, inScene: !!world.grass.parent, bs: world.grass.boundingSphere && [world.grass.boundingSphere.center.toArray().map(v=>+v.toFixed(1)), +world.grass.boundingSphere.radius.toFixed(1)], visible: world.grass.visible, hasSh: !!world.grass.material.userData.sh, tex: !!world.grass.material.map.image }); window.__dbg = () => ({ P: { ...P }, cam: camera.position.toArray().map(v => +v.toFixed(2)), heroScale: hero.scale.x, heroH: robotHeight(hero), fps: renderer.info.render.frame, tris: renderer.info.render.triangles, calls: renderer.info.render.calls });
}
boot().catch(e => { console.error(e); ltext.textContent = 'تعذّر التحميل: ' + e.message; });

// ---------- الحركات ----------
function play(name, fade = 0.25, once = false) {
  const act = actions[name]; if (!act || current === act) return;
  act.reset(); act.enabled = true; act.setEffectiveWeight(1); if (current) current.crossFadeTo(act, fade, true); act.play(); current = act;
  if (once) { const back = e => { if (e.action === act) { mixer.removeEventListener('finished', back); current = null; play('Idle', 0.3); } }; mixer.addEventListener('finished', back); }
}

// ---------- الإدخال ----------
const keys = {}; let joy = { active: false, id: null, ox: 0, oy: 0, dx: 0, dy: 0 }; let look = { active: false, id: null, lx: 0, ly: 0 };
let wantJump = false, wantInteract = false;
function setupInput() {
  addEventListener('keydown', e => { keys[e.code] = true; if (e.code === 'Space') { wantJump = true; e.preventDefault(); } if (e.code === 'KeyE' || e.code === 'Enter') { if (!uiOpen) wantInteract = true; } if (e.code === 'Escape') closePanel(); });
  addEventListener('keyup', e => { keys[e.code] = false; });
  // ماوس: سحبٌ للنظر
  canvas.addEventListener('mousedown', e => { if (uiOpen) return; look.active = true; look.lx = e.clientX; look.ly = e.clientY; cam.auto = false; });
  addEventListener('mouseup', () => { look.active = false; });
  addEventListener('mousemove', e => { if (look.active) { cam.yaw -= (e.clientX - look.lx) * 0.005; cam.pitch = THREE.MathUtils.clamp(cam.pitch + (e.clientY - look.ly) * 0.003, 0.05, 1.1); look.lx = e.clientX; look.ly = e.clientY; } });
  // لمس: عصا يمينًا ونظرٌ يسارًا
  const jbase = $('joy'), jknob = $('knob');
  canvas.addEventListener('touchstart', e => {
    for (const t of e.changedTouches) {
      if (t.clientX > innerWidth * 0.5 && !joy.active) { joy = { active: true, id: t.identifier, ox: t.clientX, oy: t.clientY, dx: 0, dy: 0 }; jbase.style.display = 'block'; jbase.style.left = (t.clientX - 60) + 'px'; jbase.style.top = (t.clientY - 60) + 'px'; jknob.style.transform = 'translate(0,0)'; }
      else if (t.clientX <= innerWidth * 0.5 && !look.active) { look = { active: true, id: t.identifier, lx: t.clientX, ly: t.clientY }; cam.auto = false; }
    }
    e.preventDefault();
  }, { passive: false });
  canvas.addEventListener('touchmove', e => {
    for (const t of e.changedTouches) {
      if (joy.active && t.identifier === joy.id) { let dx = t.clientX - joy.ox, dy = t.clientY - joy.oy; const d = Math.hypot(dx, dy); if (d > 55) { dx *= 55 / d; dy *= 55 / d; } joy.dx = dx / 55; joy.dy = dy / 55; jknob.style.transform = `translate(${dx}px,${dy}px)`; }
      if (look.active && t.identifier === look.id) { cam.yaw -= (t.clientX - look.lx) * 0.006; cam.pitch = THREE.MathUtils.clamp(cam.pitch + (t.clientY - look.ly) * 0.004, 0.05, 1.1); look.lx = t.clientX; look.ly = t.clientY; }
    }
    e.preventDefault();
  }, { passive: false });
  const endT = e => { for (const t of e.changedTouches) { if (joy.active && t.identifier === joy.id) { joy.active = false; joy.dx = joy.dy = 0; jbase.style.display = 'none'; } if (look.active && t.identifier === look.id) look.active = false; } };
  canvas.addEventListener('touchend', endT); canvas.addEventListener('touchcancel', endT);
  $('jump').addEventListener('touchstart', e => { wantJump = true; e.preventDefault(); }, { passive: false }); $('jump').addEventListener('click', () => { wantJump = true; });
  $('act').addEventListener('click', () => { wantInteract = true; });
  if (isTouch) document.body.classList.add('touch');
}

// ---------- التصادم ----------
function collide() {
  for (const c of world.colliders) { const dx = P.x - c.x, dz = P.z - c.z; const d = Math.hypot(dx, dz), m = c.r + 0.45; if (d < m && d > 1e-4) { P.x += dx / d * (m - d); P.z += dz / d * (m - d); } }
  for (const b of world.boxes) { if (b.gate && b.open) continue; const x0 = b.x0 - 0.45, x1 = b.x1 + 0.45, z0 = b.z0 - 0.45, z1 = b.z1 + 0.45; if (P.x > x0 && P.x < x1 && P.z > z0 && P.z < z1) { const dl = P.x - x0, dr = x1 - P.x, dn = P.z - z0, df = z1 - P.z; const m = Math.min(dl, dr, dn, df); if (m === dl) P.x = x0; else if (m === dr) P.x = x1; else if (m === dn) P.z = z0; else P.z = z1; } }
  P.x = THREE.MathUtils.clamp(P.x, X0 + 5, X1 - 3); P.z = THREE.MathUtils.clamp(P.z, -WID * 0.44, WID * 0.44);
}

// ---------- الحلقة ----------
const clock = new THREE.Clock(); let t = 0; let nearTarget = null;
function loop() {
  const dt = Math.min(clock.getDelta(), 0.05); t += dt;
  // اتّجاهُ الحركة نسبةً إلى الكاميرا
  let ix = 0, iz = 0;
  if (!uiOpen) { if (keys.KeyW || keys.ArrowUp) iz -= 1; if (keys.KeyS || keys.ArrowDown) iz += 1; if (keys.KeyA || keys.ArrowLeft) ix -= 1; if (keys.KeyD || keys.ArrowRight) ix += 1; if (joy.active) { ix += joy.dx; iz += joy.dy; } }
  const mag = Math.min(1, Math.hypot(ix, iz));
  const run = keys.ShiftLeft || keys.ShiftRight || (joy.active && mag > 0.85);
  const target = mag > 0.05 ? (run ? 6.2 : 3.4) * Math.min(1, mag / 0.85) : 0;
  P.speed += (target - P.speed) * (1 - Math.exp(-dt * 9));
  if (mag > 0.05) {
    const fwd = new THREE.Vector3(-Math.sin(cam.yaw), 0, -Math.cos(cam.yaw)), right = new THREE.Vector3(fwd.z, 0, -fwd.x);
    const dir = fwd.multiplyScalar(-iz).add(right.multiplyScalar(ix)).normalize();
    const want = Math.atan2(dir.x, dir.z); let d = want - P.yaw; d = Math.atan2(Math.sin(d), Math.cos(d)); P.yaw += d * (1 - Math.exp(-dt * 12));
    P.x += Math.sin(P.yaw) * P.speed * dt; P.z += Math.cos(P.yaw) * P.speed * dt;
    if (cam.auto || !look.active) { let cd = (P.yaw + Math.PI) - cam.yaw; cd = Math.atan2(Math.sin(cd), Math.cos(cd)); if (!look.active) cam.yaw += cd * (1 - Math.exp(-dt * 1.2)); }
  }
  collide();
  // قفز
  const gy = H(P.x, P.z);
  if (wantJump && P.grounded && !uiOpen) { P.vy = 6.2; P.grounded = false; P.jumping = true; play('Jump', 0.08, true); actions.Jump.timeScale = 1.15; sfx('open'); }
  wantJump = false;
  if (!P.grounded) { P.vy -= 16 * dt; P.y += P.vy * dt; if (P.y <= gy) { P.y = gy; P.vy = 0; P.grounded = true; P.jumping = false; } } else P.y = gy;
  if (!P.jumping && !(current && (current === actions.Victory || current === actions.Defeat || current === actions.Waving || current === actions.Hip_Hop_Dancing))) play(P.speed > 4.6 ? 'Running' : P.speed > 0.4 ? 'Walking' : 'Idle', 0.22);
  if (current === actions.Walking) current.timeScale = 0.9 + P.speed * 0.1; if (current === actions.Running) current.timeScale = 0.85 + P.speed * 0.05;
  hero.position.set(P.x, P.y, P.z); hero.rotation.y = P.yaw; mixer.update(dt);
  world.mixers.forEach(m => m.update(dt));
  // كاميرا
  heroPos.set(P.x, P.y + 1.35, P.z);
  const cx = P.x + Math.sin(cam.yaw) * Math.cos(cam.pitch) * cam.dist, cz = P.z + Math.cos(cam.yaw) * Math.cos(cam.pitch) * cam.dist; let cy = P.y + 1.2 + Math.sin(cam.pitch) * cam.dist;
  cy = Math.max(cy, H(cx, cz) + 0.7); if (!cam.snapped) { camera.position.set(cx, cy, cz); cam.snapped = true; } else camera.position.lerp(new THREE.Vector3(cx, cy, cz), 1 - Math.exp(-dt * 10)); camera.lookAt(heroPos);
  // الشمس تتبع اللاعب
  sun.position.copy(sunDir).multiplyScalar(60).add(hero.position); sun.target.position.copy(hero.position);
  // فوانيس: أقربُ أربعة
  const ls = world.lanterns.map(l => ({ l, d: Math.hypot(l.x - P.x, l.z - P.z) })).sort((a, b) => a.d - b.d).slice(0, 4);
  lanternLights.forEach((pl, i) => { if (ls[i] && ls[i].d < 40) { pl.position.set(ls[i].l.x, ls[i].l.y, ls[i].l.z); pl.intensity = 6 + Math.sin(t * 7 + i) * 0.6; } else pl.intensity = 0; });
  // غبارٌ يتبع اللاعب
  world.dust.position.set(Math.round(P.x / 10) * 10, 0, Math.round(P.z / 10) * 10); world.dust.rotation.y = t * 0.02;
  world.water.material.normalMap.offset.set(t * 0.012, t * 0.007);
  // المحطّات والبوّابات
  for (const g of world.animated) { const u = g.userData; if (u.st) { u.ring.rotation.z = t * 0.8; u.icon.position.y = 1.9 + Math.sin(t * 2 + u.x) * 0.12; u.beam.material.opacity = u.done ? 0 : 0.12 + Math.sin(t * 2) * 0.05; u.ring.material.color.setHex(u.done ? 0x9bd88a : STYLE[u.st.t].ring); u.icon.visible = !u.done; } if (u.field) { u.field.material.opacity = u.open ? 0 : 0.18 + Math.sin(t * 3) * 0.06; } }
  world.finish.ring.rotation.z = t * 0.5;
  updateProximity();
  updateHUD();
  renderer.render(scene, camera);
}

// ---------- القرب والتفاعل ----------
let hunting = null;   // المحطّةُ التي نبحث لها
function updateProximity() {
  let best = null, bd = 1e9;
  const consider = (kind, x, z, r, ref, label) => { const d = Math.hypot(P.x - x, P.z - z); if (d < r && d < bd) { bd = d; best = { kind, ref, label, x, z }; } };
  for (const s of world.stations) if (!s.done) consider('station', s.x, s.z, 3.2, s, STYLE[s.st.t].label + ' · ' + s.st.tag);
  for (const gd of world.guards) if (!gd.gate.open) consider('guard', gd.x, gd.z, 4.2, gd, 'حارسُ البوّابة');
  if (hunting) { if (hunting.st.pick[0].match(/^[٠-٩]/)) { for (const s of world.signs) consider('sign', s.x, s.z, 2.4, s, 'لافتة ' + s.sign); } else { for (const a of world.animals) consider('animal', a.x, a.z, 2.6, a, a.tag); } }
  if (allDone()) consider('finish', world.finish.x, world.finish.z, 3.6, world.finish, 'منصّةُ الختام');
  nearTarget = best;
  const btn = $('act'); if (best && !uiOpen) { btn.style.display = 'flex'; btn.querySelector('span').textContent = best.label; } else btn.style.display = 'none';
  if (wantInteract && best && !uiOpen) interact(best);
  wantInteract = false;
}
function interact(tg) {
  sfx('click');
  if (tg.kind === 'station') openStation(tg.ref);
  else if (tg.kind === 'guard') openGuard(tg.ref);
  else if (tg.kind === 'animal' || tg.kind === 'sign') checkHunt(tg);
  else if (tg.kind === 'finish') openFinish();
}

// ---------- الواجهة ----------
let uiOpen = false; let score = 0; let progress = {};
try { progress = JSON.parse(localStorage.getItem('zakat.progress.' + topic.id) || '{}'); score = progress.score || 0; } catch (e) { }
function buildHUD() {
  $('hname').textContent = player.name; $('hrobot').style.background = '#' + rdef.accent.toString(16).padStart(6, '0');
  document.documentElement.style.setProperty('--accent', '#' + rdef.accent.toString(16).padStart(6, '0'));
  // استرجاعُ التقدّم
  if (progress.done) { for (const k of progress.done) { const s = world.stations.find(s => s.st.region + ':' + s.st.index === k); if (s) s.done = true; } }
  if (progress.gates) { for (const i of progress.gates) openGateNow(world.gates[i]); }
  if (progress.x !== undefined && progress.x > START_X) { P.x = progress.x; P.z = progress.z || 0; }
}
function saveProgress() { progress.done = world.stations.filter(s => s.done).map(s => s.st.region + ':' + s.st.index); progress.gates = world.gates.filter(g => g.open).map(g => g.idx); progress.score = score; progress.x = P.x; progress.z = P.z; try { localStorage.setItem('zakat.progress.' + topic.id, JSON.stringify(progress)); } catch (e) { } }
const allDone = () => world.stations.every(s => s.done) && world.gates.every(g => g.open);
function updateHUD() {
  const ri = regionOf(P.x); const rg = topic.regions[ri];
  if ($('rname').textContent !== rg.name) { $('rname').textContent = rg.name; $('rsub').textContent = rg.sub; }
  const dots = $('dots'); const sts = world.stations.filter(s => s.st.region === ri); if (dots.childElementCount !== sts.length) { dots.innerHTML = sts.map(() => '<i></i>').join(''); }
  sts.forEach((s, i) => dots.children[i].classList.toggle('on', s.done));
  $('score').textContent = AR(score);
  $('hint').textContent = hunting ? 'ابحثْ: ' + hunting.st.hint : '';
}
function toast(msg, ms = 2600) { const el = $('toast'); el.textContent = msg; el.classList.add('show'); clearTimeout(el._t); el._t = setTimeout(() => el.classList.remove('show'), ms); }
const sounds = {}; function sfx(n) { try { if (!sounds[n]) { sounds[n] = new Audio(A('sfx/' + n + '.mp3')); sounds[n].volume = 0.5; } sounds[n].currentTime = 0; sounds[n].play().catch(() => { }); } catch (e) { } }

function openPanel(html) { $('pbody').innerHTML = html; $('panel').classList.add('open'); uiOpen = true; joy.active = false; joy.dx = joy.dy = 0; $('joy').style.display = 'none'; }
function closePanel() { $('panel').classList.remove('open'); uiOpen = false; }
$('pclose').onclick = closePanel;

let active = null;   // {kind:'station'|'guard', ref, q}
function qHead(style, tag, q) { return `<div class="qtag" style="--c:#${style.ring.toString(16).padStart(6, '0')}"><b>${style.icon}</b> ${style.label}${tag ? ' · ' + tag : ''}</div><div class="qtext">${q}</div>`; }
function openStation(s) {
  active = { kind: 'station', ref: s, q: s.st }; const st = s.st, style = STYLE[st.t];
  if (st.t === 'hunt') { hunting = s; openPanel(qHead(style, st.tag, st.q) + `<div class="note">تلميح: ${st.hint}</div><button class="go" id="gohunt">انطلقْ للبحث</button>`); $('gohunt').onclick = () => { closePanel(); toast('امشِ إلى الهدف واضغطْ عنده', 3000); }; return; }
  if (st.t === 'lock') { openPanel(qHead(style, st.tag, st.q) + `<div class="lock"><div class="lcd" id="lcd">—</div><div class="pad">${[1, 2, 3, 4, 5, 6, 7, 8, 9, '⌫', 0, '✓'].map(k => `<button data-k="${k}">${typeof k === 'number' ? AR(k) : k}</button>`).join('')}</div></div>`); let v = ''; $('pbody').querySelectorAll('.pad button').forEach(b => b.onclick = () => { const k = b.dataset.k; if (k === '⌫') v = v.slice(0, -1); else if (k === '✓') { answer(parseInt(v || '-1', 10) === st.ans); return; } else if (v.length < 4) v += k; $('lcd').textContent = v ? AR(v) : '—'; sfx('select'); }); return; }
  openChoices(style, st.tag, st);
}
function openChoices(style, tag, q) {
  const opts = q.t === 'tf' ? ['صواب', 'خطأ'] : q.o;
  openPanel(qHead(style, tag, q.q) + `<div class="opts">${opts.map((o, i) => `<button data-i="${i}">${o}</button>`).join('')}</div>`);
  $('pbody').querySelectorAll('.opts button').forEach(b => b.onclick = () => { const i = +b.dataset.i; const ok = q.t === 'tf' ? (i === 0) === q.a : i === q.a; b.classList.add(ok ? 'ok' : 'no'); answer(ok); });
}
function openGuard(gd) { const q = topic.regions[gd.region].guard; active = { kind: 'guard', ref: gd, q }; openChoices(STYLE.guard, topic.regions[gd.region].name, q); }
function answer(ok) {
  const ref = active.ref; ref.tries = (ref.tries || 0) + 1;
  if (ok) {
    const pts = ref.tries === 1 ? 10 : ref.tries === 2 ? 5 : 2; score += pts; sfx('good'); play('Victory', 0.15, true);
    if (active.kind === 'station') { ref.done = true; burst(ref.x, ref.z, STYLE[ref.st.t].ring); } else { openGateNow(ref.gate); sfx('gate'); burst(ref.gate.x, 0, 0xffd27a); }
    saveProgress();
    $('pbody').innerHTML = `<div class="res ok"><div class="big">أحسنت! +${AR(pts)}</div><div class="why">${active.q.w}</div>${allDone() ? '<div class="note">اكتملت الرحلة — اذهب إلى منصّة الختام في آخر السوق</div>' : ''}<button class="go" id="cont">تابعْ</button></div>`;
    $('cont').onclick = closePanel;
  } else {
    sfx('bad'); play('Defeat', 0.15, true);
    $('pbody').innerHTML = `<div class="res no"><div class="big">ليست هذه</div><div class="why">${ref.tries >= 2 ? active.q.w : 'فكّرْ مرّةً أخرى — راجعْ ما درسته.'}</div><button class="go" id="retry">حاولْ ثانية</button></div>`;
    $('retry').onclick = () => { if (active.kind === 'guard') openGuard(ref); else openStation(ref); };
  }
}
function checkHunt(tg) {
  const st = hunting.st; const val = tg.kind === 'animal' ? tg.ref.tag : tg.ref.sign; const ok = st.pick.includes(val);
  hunting.tries = (hunting.tries || 0) + 1;
  if (ok) { const pts = hunting.tries === 1 ? 10 : hunting.tries === 2 ? 5 : 2; score += pts; hunting.done = true; burst(tg.x, tg.z, STYLE.hunt.ring); sfx('good'); play('Victory', 0.15, true); saveProgress(); openPanel(`<div class="res ok"><div class="big">صحيح! ${val} · +${AR(pts)}</div><div class="why">${st.w}</div><button class="go" id="cont">تابعْ</button></div>`); $('cont').onclick = closePanel; hunting = null; }
  else { sfx('bad'); play('Defeat', 0.15, true); toast(`${val}؟ ليس المطلوب — ${hunting.tries >= 2 ? st.w : 'جرّبْ غيره'}`, 3600); }
}
function openGateNow(g) { g.open = true; g.wall.open = true; }
function openFinish() {
  uiOpen = true; play('Hip_Hop_Dancing', 0.3); for (let i = 0; i < 6; i++) setTimeout(() => burst(world.finish.x + (Math.random() - .5) * 6, world.finish.z + (Math.random() - .5) * 6, [0xffd27a, 0x35d6ff, 0x7ee08a, 0xff7a1a][i % 4]), i * 350);
  sfx('region');
  openPanel(`<div class="res ok"><div class="big">أتممتَ رحلة الزكاة يا ${player.name}!</div><div class="why">مجموعُ نقاطك: <b>${AR(score)}</b> من ${AR(150)}<br>المحطّات: ${AR(world.stations.length)} · البوّابات: ${AR(world.gates.length)}</div><button class="go" id="again">العودة إلى شاشة الدخول</button></div>`);
  $('again').onclick = () => { try { localStorage.setItem('zakat.result.' + topic.id, JSON.stringify({ name: player.name, robot: player.robot, score, at: Date.now() })); localStorage.removeItem('zakat.progress.' + topic.id); } catch (e) { } location.href = 'index.html'; };
}

// ---------- انفجارُ نجوم ----------
const sparkTex = loadTex(A('fx/star.png'));
function burst(x, z, color) {
  const n = 60, pos = new Float32Array(n * 3), vel = []; const y0 = H(x, z) + 0.8;
  for (let i = 0; i < n; i++) { pos.set([x, y0, z], i * 3); const a = Math.random() * 6.28, s = 2 + Math.random() * 4; vel.push([Math.cos(a) * s, 3 + Math.random() * 5, Math.sin(a) * s]); }
  const pts = new THREE.Points(new THREE.BufferGeometry().setAttribute('position', new THREE.BufferAttribute(pos, 3)), new THREE.PointsMaterial({ map: sparkTex, color, size: 0.5, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending }));
  scene.add(pts); const born = performance.now();
  const step = () => { const dt = 0.016, age = (performance.now() - born) / 1000; const p = pts.geometry.attributes.position; for (let i = 0; i < n; i++) { vel[i][1] -= 9 * dt; p.setXYZ(i, p.getX(i) + vel[i][0] * dt, Math.max(y0 - 0.7, p.getY(i) + vel[i][1] * dt), p.getZ(i) + vel[i][2] * dt); } p.needsUpdate = true; pts.material.opacity = 1 - age / 1.6; if (age < 1.6) requestAnimationFrame(step); else { scene.remove(pts); pts.geometry.dispose(); pts.material.dispose(); } };
  step();
}
