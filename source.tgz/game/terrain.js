// التضاريس: شريطٌ متّصلٌ من ثلاث مناطق، سطحٌ بأربع خاماتٍ PBR تُمزَج حسب المنطقة والانحدار والدرب.
import * as THREE from 'three';

export const LEN = 240, WID = 96;          // x ∈ [-120,120] · z ∈ [-48,48]
export const X0 = -LEN / 2, X1 = LEN / 2;
export const GATE_X = [-40, 40];
export const START_X = -104;
export const REGION_CENTER = [-80, 0, 80];

// ---------- ضجيج ----------
const perm = new Uint8Array(512); { const p = []; for (let i = 0; i < 256; i++) p[i] = i; let s = 1337; for (let i = 255; i > 0; i--) { s = (s * 16807) % 2147483647; const j = s % (i + 1); [p[i], p[j]] = [p[j], p[i]]; } for (let i = 0; i < 512; i++) perm[i] = p[i & 255]; }
const fade = t => t * t * t * (t * (t * 6 - 15) + 10);
const grad = (h, x, y) => { switch (h & 3) { case 0: return x + y; case 1: return -x + y; case 2: return x - y; default: return -x - y; } };
export function noise(x, y) {
  const X = Math.floor(x) & 255, Y = Math.floor(y) & 255; x -= Math.floor(x); y -= Math.floor(y);
  const u = fade(x), v = fade(y), A = perm[X] + Y, B = perm[X + 1] + Y;
  return THREE.MathUtils.lerp(THREE.MathUtils.lerp(grad(perm[A], x, y), grad(perm[B], x - 1, y), u), THREE.MathUtils.lerp(grad(perm[A + 1], x, y - 1), grad(perm[B + 1], x - 1, y - 1), u), v) * 0.5 + 0.5;
}
export function fbm(x, y, o = 4) { let a = 0.5, f = 1, s = 0, n = 0; for (let i = 0; i < o; i++) { s += a * noise(x * f, y * f); n += a; a *= 0.5; f *= 2.1; } return s / n; }
const clamp01 = v => Math.min(1, Math.max(0, v));
const smooth = (a, b, x) => { const t = clamp01((x - a) / (b - a)); return t * t * (3 - 2 * t); };

// أوزانُ المناطق عند x (مرعى · وادٍ · سوق)
export function regionW(x) {
  const w = [0, 0, 0];
  const t1 = smooth(GATE_X[0] - 12, GATE_X[0] + 12, x), t2 = smooth(GATE_X[1] - 12, GATE_X[1] + 12, x);
  w[0] = 1 - t1; w[1] = t1 * (1 - t2); w[2] = t2; return w;
}
export const regionOf = x => x < GATE_X[0] ? 0 : x < GATE_X[1] ? 1 : 2;

// الارتفاع
export function H(x, z) {
  const w = regionW(x);
  const amp = w[0] * 4.6 + w[1] * 3.6 + w[2] * 1.2;
  let h = (fbm(x * 0.022 + 7, z * 0.024 + 3, 4) - 0.5) * 2 * amp;
  const az = Math.abs(z);
  h *= 0.25 + 0.75 * clamp01((az - 6.5) / 14);           // الدربُ مستوٍ
  const edge = Math.max(0, az - WID * 0.4) / 20; h += 15 * (1 - Math.exp(-edge * edge));   // الحوافُّ تلال
  const ends = Math.max(0, Math.abs(x) - X1 + 14) / 18; h += 13 * (1 - Math.exp(-ends * ends));
  // بركةُ الوادي: منخفضٌ لطيف
  const pd = Math.hypot((x - 8) / 16, (z - 16) / 11); h -= 1.6 * (1 - smooth(0.55, 1.05, pd));
  // ساحةُ السوق مستوية
  const md = Math.hypot((x - 82) / 26, z / 20); h *= 1 - 0.85 * (1 - smooth(0.6, 1.0, md));
  return h;
}
export function slopeAt(x, z) { const e = 1; return Math.hypot(H(x + e, z) - H(x - e, z), H(x, z + e) - H(x, z - e)) / (2 * e); }
export const onRoad = (x, z) => 1 - smooth(4.5, 8.5, Math.abs(z + Math.sin(x * 0.05) * 1.5));

// ---------- خامةُ المزج ----------
export function splatMaterial(T) {
  // T: {d0,n0, d1,n1, d2,n2, d3,n3}   0 عشب · 1 تربة جافّة · 2 رملٌ أحمر · 3 حصى السوق
  const m = new THREE.MeshStandardMaterial({ map: T.d0, normalMap: T.n0, roughness: 0.96, metalness: 0, normalScale: new THREE.Vector2(0.9, 0.9) });
  m.onBeforeCompile = sh => {
    sh.uniforms.d1 = { value: T.d1 }; sh.uniforms.d2 = { value: T.d2 }; sh.uniforms.d3 = { value: T.d3 };
    sh.uniforms.n1 = { value: T.n1 }; sh.uniforms.n2 = { value: T.n2 }; sh.uniforms.n3 = { value: T.n3 };
    sh.vertexShader = sh.vertexShader
      .replace('#include <common>', '#include <common>\nattribute vec4 splat; varying vec4 vSplat; varying vec2 vTUv;')
      .replace('#include <begin_vertex>', '#include <begin_vertex>\nvSplat = splat; vTUv = position.xz;');
    sh.fragmentShader = sh.fragmentShader
      .replace('#include <common>', `#include <common>
uniform sampler2D d1, d2, d3, n1, n2, n3; varying vec4 vSplat; varying vec2 vTUv;
vec4 splat4(sampler2D a, sampler2D b, sampler2D c, sampler2D d, vec2 uv){
  vec2 u = uv * 0.28; vec2 u2 = uv * 0.071;   // ترددان: تفصيلٌ + كبيرٌ يكسر التكرار
  vec4 w = vSplat; w /= max(1e-3, w.x + w.y + w.z + w.w);
  vec4 s = texture2D(a, u) * w.x + texture2D(b, u) * w.y + texture2D(c, u) * w.z + texture2D(d, u) * w.w;
  vec4 s2 = texture2D(a, u2) * w.x + texture2D(b, u2) * w.y + texture2D(c, u2) * w.z + texture2D(d, u2) * w.w;
  return mix(s, s2, 0.35);
}`)
      .replace('vec4 sampledDiffuseColor = texture2D( map, vMapUv );', 'vec4 sampledDiffuseColor = splat4(map, d1, d2, d3, vTUv); ')
      .replace('vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;', 'vec3 mapN = splat4(normalMap, n1, n2, n3, vTUv).xyz * 2.0 - 1.0;');
  };
  m.customProgramCacheKey = () => 'splat';
  return m;
}

// ---------- بناءُ الشبكة ----------
export function buildTerrain(mat) {
  const res = 1.5, nx = Math.round(LEN / res), nz = Math.round(WID / res);
  const geo = new THREE.PlaneGeometry(LEN, WID, nx, nz); geo.rotateX(-Math.PI / 2);
  const pos = geo.attributes.position, n = pos.count; const spl = new Float32Array(n * 4);
  for (let i = 0; i < n; i++) {
    const x = pos.getX(i), z = pos.getZ(i); const y = H(x, z); pos.setY(i, y);
    const w = regionW(x), sl = slopeAt(x, z), road = onRoad(x, z);
    const md = Math.hypot((x - 82) / 24, z / 18); const souq = 1 - smooth(0.7, 1.0, md);
    const var1 = fbm(x * 0.05 + 3, z * 0.05 + 9, 3);
    let g = w[0] * 1.3 * (1 - sl * 0.5) + w[1] * 0.25 * var1, dry = w[1] * 0.3 + w[0] * 0.12 * var1 + sl * 0.9, sand = w[2] * 1.1 + w[1] * 0.75 * (1 - var1 * 0.5), cob = souq * w[2] * 1.8;
    dry += road * 1.6; g *= 1 - road * 0.85; sand *= 1 - road * 0.7;
    const hi = smooth(9, 14, y); dry += hi * 1.5; g *= 1 - hi;
    spl.set([Math.max(0, g), Math.max(0, dry), Math.max(0, sand), Math.max(0, cob)], i * 4);
  }
  geo.setAttribute('splat', new THREE.BufferAttribute(spl, 4));
  geo.computeVertexNormals();
  const mesh = new THREE.Mesh(geo, mat); mesh.receiveShadow = true; mesh.name = 'terrain';
  return mesh;
}
