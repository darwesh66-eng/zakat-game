// شاشة الدخول — رحلة الزكاة
import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/examples/jsm/postprocessing/OutputPass.js';

const A = p => (window.__FLAT ? 'assets__' + p.replace(/\//g,'__') : 'assets/' + p);
// موضع الشمس في صورة السماء (rogland_sunset): سمت 0.628 راد، ارتفاع 12.6°
const SUN_AZ = 0.628, SUN_EL = 0.22, SKY_ROT = 0.314;
const sunDir = new THREE.Vector3(Math.cos(SUN_AZ+SKY_ROT)*Math.cos(SUN_EL), Math.sin(SUN_EL), Math.sin(SUN_AZ+SKY_ROT)*Math.cos(SUN_EL));
const ROBOTS = [
  { id:'noor',   name:'نور',    model:'ybot',     accent:0x35d6ff, body:0xdfe3e8, joints:0x1c2026, desc:'رشيقٌ سريعُ الخُطى' },
  { id:'shihab', name:'شهاب',   model:'xbot',     accent:0xff7a1a, body:0xe6e1d6, joints:0x23201c, desc:'قويٌّ لا يتعب' },
  { id:'haris',  name:'حارس',   model:'vanguard', accent:0xffd166, body:null,     joints:null,     desc:'مدرَّعٌ حارسُ القافلة' },
  { id:'zumurrud', name:'زمرّد', model:'xbot',     accent:0x3cff9a, body:0x2a2f38, joints:0x0f1216, desc:'هادئٌ حكيمُ القرار' },
];
const CLIPS = ['Idle','Waving','Hip_Hop_Dancing','Victory','Running','Looking_Around'];
const PREVIEW = [ ['تحيّة','Waving'], ['رقصة','Hip_Hop_Dancing'], ['فرحة','Victory'], ['جري','Running'] ];

// ---------- renderer ----------
const canvas = document.getElementById('c');
const isTouch = matchMedia('(pointer:coarse)').matches;
const renderer = new THREE.WebGLRenderer({ canvas, antialias:true, powerPreference:'high-performance' });
renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 0.62;
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
const DPR = Math.min(devicePixelRatio || 1, isTouch ? 1.5 : 2);
renderer.setPixelRatio(DPR);

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(30, 1, 0.1, 400);
const camRig = { target:new THREE.Vector3(0,1.1,0), pos:new THREE.Vector3(0,2.2,11), goalT:new THREE.Vector3(0,1.1,0), goalP:new THREE.Vector3(0,2.2,11) };

const composer = new EffectComposer(renderer);
const renderPass = new RenderPass(scene, camera); composer.addPass(renderPass);
const bloom = new UnrealBloomPass(new THREE.Vector2(512,512), 0.38, 0.55, 0.96); composer.addPass(bloom);
composer.addPass(new OutputPass());

function resize(){
  const w = innerWidth, h = innerHeight;
  renderer.setSize(w, h, false); composer.setSize(w, h);
  bloom.resolution.set(Math.floor(w*DPR/2), Math.floor(h*DPR/2));
  camera.aspect = w/h; camera.updateProjectionMatrix();
  layoutCamera();
}
addEventListener('resize', resize);

// ---------- loaders ----------
const manager = new THREE.LoadingManager();
const gltf = new GLTFLoader(manager); const tex = new THREE.TextureLoader(manager);
const img = new THREE.ImageLoader(manager); const loadImg = u => new Promise((res, rej) => img.load(u, res, undefined, rej));
// السماء HDR مخزونة كصورتين PNG (RGB + الأسّ E) لتُقرأ بلا مكتبةٍ إضافيّة وبلا مشاكل الشفافيّة
async function loadSkyHDR(){
  const [rgb, e] = await Promise.all([loadImg(A('env/sky_rgb.png')), loadImg(A('env/sky_e.png'))]);
  const w = rgb.width, h = rgb.height; const c = document.createElement('canvas'); c.width = w; c.height = h; const g = c.getContext('2d', { willReadFrequently:true });
  g.drawImage(rgb, 0, 0); const P = g.getImageData(0, 0, w, h).data; g.drawImage(e, 0, 0); const E = g.getImageData(0, 0, w, h).data;
  const out = new Uint16Array(w*h*4); const f16 = THREE.DataUtils.toHalfFloat;
  for (let i = 0, n = w*h; i < n; i++){ const ex = E[i*4]; const s = ex ? Math.min(Math.pow(2, ex - 136), 200) : 0; const j = i*4;
    out[j] = f16(P[j]*s); out[j+1] = f16(P[j+1]*s); out[j+2] = f16(P[j+2]*s); out[j+3] = f16(1); }
  const t = new THREE.DataTexture(out, w, h, THREE.RGBAFormat, THREE.HalfFloatType); t.flipY = true; t.colorSpace = THREE.LinearSRGBColorSpace; t.magFilter = t.minFilter = THREE.LinearFilter; t.generateMipmaps = false; t.needsUpdate = true; return t;
}
// داخل صندوق الأرتيفاكت تُمنع روابط blob: فنحوّل صور الـGLB المضمّنة إلى data: URI قبل التحليل
function glbInlineImages(buf){
  const dv = new DataView(buf); if (dv.getUint32(0, true) !== 0x46546C67) return buf;
  const jsonLen = dv.getUint32(12, true); const jsonStr = new TextDecoder().decode(new Uint8Array(buf, 20, jsonLen)); const json = JSON.parse(jsonStr);
  const binOff = 20 + jsonLen + 8; const binLen = dv.getUint32(20 + jsonLen, true); const bin = new Uint8Array(buf, binOff, binLen);
  if (!json.images || !json.images.some(im => im.bufferView !== undefined)) return buf;
  const b64 = a => { let s = ''; for (let i = 0; i < a.length; i += 0x8000) s += String.fromCharCode.apply(null, a.subarray(i, i + 0x8000)); return btoa(s); };
  for (const im of json.images){ if (im.bufferView === undefined) continue; const bv = json.bufferViews[im.bufferView]; const slice = bin.subarray(bv.byteOffset || 0, (bv.byteOffset || 0) + bv.byteLength); im.uri = 'data:' + (im.mimeType || 'image/png') + ';base64,' + b64(slice); delete im.bufferView; delete im.mimeType; }
  let js = new TextEncoder().encode(JSON.stringify(json)); const pad = (4 - js.length % 4) % 4; if (pad){ const t = new Uint8Array(js.length + pad); t.set(js); t.fill(0x20, js.length); js = t; }
  const out = new ArrayBuffer(12 + 8 + js.length + 8 + binLen); const o = new DataView(out); const u8 = new Uint8Array(out);
  o.setUint32(0, 0x46546C67, true); o.setUint32(4, 2, true); o.setUint32(8, out.byteLength, true);
  o.setUint32(12, js.length, true); o.setUint32(16, 0x4E4F534A, true); u8.set(js, 20);
  o.setUint32(20 + js.length, binLen, true); o.setUint32(24 + js.length, 0x004E4942, true); u8.set(bin, 28 + js.length);
  return out;
}
const loadGLB = u => window.__ARTIFACT
  ? fetch(u + '.txt').then(r => r.text()).then(b64 => { const bin = atob(b64); const a = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) a[i] = bin.charCodeAt(i); return new Promise((res, rej) => gltf.parse(glbInlineImages(a.buffer), u.slice(0, u.lastIndexOf('/')+1), res, rej)); })
  : new Promise((res, rej) => gltf.load(u, res, undefined, rej));
const loadTex = (u, srgb=false, rep=1) => { const t = tex.load(u); t.wrapS=t.wrapT=THREE.RepeatWrapping; t.repeat.set(rep,rep); if(srgb) t.colorSpace=THREE.SRGBColorSpace; t.anisotropy = 8; return t; };
const bar = document.getElementById('bar'), loader = document.getElementById('loader');
manager.onProgress = (u, l, t) => { bar.style.width = Math.round(100*l/t) + '%'; };

// ---------- lights ----------
const sun = new THREE.DirectionalLight(0xffc890, 3.0); sun.position.copy(sunDir).multiplyScalar(20); sun.castShadow = true;
sun.shadow.mapSize.set(2048,2048); sun.shadow.camera.left=-8; sun.shadow.camera.right=8; sun.shadow.camera.top=8; sun.shadow.camera.bottom=-8; sun.shadow.camera.near=1; sun.shadow.camera.far=40; sun.shadow.bias=-0.0006; sun.shadow.normalBias=0.02;
scene.add(sun);
const rim = new THREE.DirectionalLight(0xffb070, 1.2); rim.position.set(6, 3, 8); scene.add(rim);
scene.add(new THREE.HemisphereLight(0xffe0c0, 0x3a2a20, 0.35));

// ---------- world ----------
const world = new THREE.Group(); scene.add(world);
function buildWorld(T){
  // الأرض الرمليّة
  const sand = new THREE.Mesh(new THREE.CircleGeometry(90, 64), new THREE.MeshStandardMaterial({ map:T.sandD, normalMap:T.sandN, aoMap:T.sandA, roughnessMap:T.sandA, metalnessMap:T.sandA, roughness:1, metalness:0 }));
  sand.rotation.x = -Math.PI/2; sand.position.y = -0.02; sand.receiveShadow = true; world.add(sand);
  // المنصّة الحجريّة
  const stone = new THREE.MeshStandardMaterial({ map:T.pavD, normalMap:T.pavN, aoMap:T.pavA, roughnessMap:T.pavA, metalnessMap:T.pavA, roughness:1 });
  const podium = new THREE.Mesh(new THREE.CylinderGeometry(4.2, 4.4, 0.55, 64), stone); podium.position.y = 0.275; podium.castShadow = podium.receiveShadow = true; world.add(podium);
  const step = new THREE.Mesh(new THREE.CylinderGeometry(5.6, 5.8, 0.25, 64), stone); step.position.y = 0.125; step.receiveShadow = true; world.add(step);
  // حلقةٌ مضيئة على المنصّة
  const ring = new THREE.Mesh(new THREE.TorusGeometry(3.9, 0.035, 8, 96), new THREE.MeshBasicMaterial({ color:0xffc070 })); ring.rotation.x = Math.PI/2; ring.position.y = 0.556; world.add(ring); world.userData.ring = ring;
  // الماء خلف المنصّة
  const water = new THREE.Mesh(new THREE.PlaneGeometry(140, 60, 1, 1), new THREE.MeshPhysicalMaterial({ color:0x1f5f7a, metalness:0.15, roughness:0.08, normalMap:T.waterN, normalScale:new THREE.Vector2(0.22,0.22), envMapIntensity:1.6, clearcoat:1, clearcoatRoughness:0.05 }));
  water.rotation.x = -Math.PI/2; water.position.set(0, 0.0, -42); world.add(water); world.userData.water = water;
  // شاطئٌ رمليّ مرتفع قليلًا حتى لا يبدو الماء قاطعًا
  const shore = new THREE.Mesh(new THREE.CylinderGeometry(30, 30, 0.6, 48), new THREE.MeshStandardMaterial({ map:T.sandD, normalMap:T.sandN, roughness:1 })); shore.position.set(0,-0.31,0); world.add(shore);
  // النخيل
  const spots = [ [-9,0,-6,0.62,'a'], [8.5,0,-7,0.7,'b'], [-14,0,-14,0.75,'b'], [14,0,-15,0.66,'a'], [-6,0,-18,0.7,'a'], [5,0,-20,0.8,'b'], [-18,0,-2,0.6,'a'], [18,0,-3,0.62,'b'] ];
  for (const [x,y,z,s,k] of spots){ const p = (k==='a'?T.palmA:T.palmB).clone(); p.position.set(x,y,z); p.scale.setScalar(s); p.rotation.y = Math.random()*6.28; p.traverse(o=>{ if(o.isMesh){ o.castShadow=true; o.material.side = THREE.DoubleSide; o.material.vertexColors = false; if (o.geometry.attributes.color) o.geometry.deleteAttribute('color'); o.material.needsUpdate = true; } }); world.add(p); }
  // غبارٌ ذهبيّ
  const n = 260, pos = new Float32Array(n*3); for(let i=0;i<n;i++){ pos[i*3]=(Math.random()-.5)*22; pos[i*3+1]=Math.random()*5+0.4; pos[i*3+2]=(Math.random()-.5)*16-2; }
  const dust = new THREE.Points(new THREE.BufferGeometry().setAttribute('position', new THREE.BufferAttribute(pos,3)), new THREE.PointsMaterial({ color:0xffd9a0, size:0.05, transparent:true, opacity:0.75, depthWrite:false, blending:THREE.AdditiveBlending }));
  world.add(dust); world.userData.dust = dust;
}

// ---------- robots ----------
const robots = []; const clips = {};
function skeletonHeight(o){ o.updateMatrixWorld(true); let top=0; const p=new THREE.Vector3(); o.traverse(b=>{ if(b.isBone){ b.getWorldPosition(p); top=Math.max(top,p.y);} }); return top || 1.7; }
function styleRobot(root, def){
  root.traverse(o => {
    if (!o.isMesh) return; o.castShadow = true; o.receiveShadow = false; o.frustumCulled = false;
    const n = (o.material.name || '').toLowerCase();
    if (def.model === 'vanguard') {
      const m = o.material.clone(); o.material = m; m.envMapIntensity = 1.0; m.roughness = 0.55; m.metalness = 0.3;
      if ((o.name||'').toLowerCase().includes('visor')) { m.emissive = new THREE.Color(def.accent); m.emissiveIntensity = 2.0; }
      return;
    }
    const isJoint = n.includes('joint');
    o.material = isJoint
      ? new THREE.MeshStandardMaterial({ color:def.joints, metalness:0.85, roughness:0.35, emissive:new THREE.Color(def.accent), emissiveIntensity:1.1 })
      : new THREE.MeshPhysicalMaterial({ color:def.body, metalness:0.05, roughness:0.32, clearcoat:0.8, clearcoatRoughness:0.15, envMapIntensity:0.8 });
  });
}
async function buildRobots(){
  const arc = [[-2.4,0,-0.4],[-0.8,0,0.4],[0.8,0,0.4],[2.4,0,-0.4]];
  const gl = await Promise.all(ROBOTS.map(r => loadGLB(A('chars/'+r.model+'.glb'))));
  ROBOTS.forEach((def, i) => {
    const root = gl[i].scene; const h = skeletonHeight(root); root.scale.setScalar(1.75/h);
    styleRobot(root, def);
    const pivot = new THREE.Group(); pivot.add(root); pivot.position.set(arc[i][0], 0.555, arc[i][2]); pivot.rotation.y = -arc[i][0]*0.12; world.add(pivot);
    // بقعة ضوءٍ ملوّنة تحت القدمين
    const glow = new THREE.Mesh(new THREE.CircleGeometry(0.75, 40), new THREE.MeshBasicMaterial({ color:def.accent, transparent:true, opacity:0.0, blending:THREE.AdditiveBlending, depthWrite:false }));
    glow.rotation.x = -Math.PI/2; glow.position.y = 0.01; pivot.add(glow);
    const mixer = new THREE.AnimationMixer(root);
    robots.push({ def, root, pivot, mixer, glow, home:pivot.position.clone(), current:null, actions:{} });
  });
}
function play(r, name, once=false){
  const clip = clips[name]; if(!clip) return;
  let act = r.actions[name]; if(!act){ act = r.mixer.clipAction(clip); r.actions[name] = act; }
  act.reset(); act.setLoop(once ? THREE.LoopOnce : THREE.LoopRepeat); act.clampWhenFinished = once; act.enabled = true; act.setEffectiveWeight(1);
  if (r.current && r.current !== act){ r.current.crossFadeTo(act, 0.35, true); }
  act.play(); r.current = act;
  if (once){ const back = e => { if(e.action===act){ r.mixer.removeEventListener('finished', back); play(r,'Idle'); } }; r.mixer.addEventListener('finished', back); }
}

// ---------- selection ----------
let selected = -1;
function select(i, preview){
  if (i === selected && !preview) return;
  const prev = selected; selected = i;
  robots.forEach((r, k) => {
    const on = k===i; r.goalPos = r.home.clone(); if(on) r.goalPos.z += 1.5; r.goalRot = on ? 0 : -r.home.x*0.12;
    if (on) play(r, 'Waving', true); else if (k===prev) play(r, 'Idle');
  });
  document.querySelectorAll('.chip').forEach((c,k)=> c.classList.toggle('on', k===i));
  const d = ROBOTS[i]; document.getElementById('rname').textContent = d.name; document.getElementById('rdesc').textContent = d.desc;
  document.documentElement.style.setProperty('--accent', '#'+d.accent.toString(16).padStart(6,'0'));
  world.userData.ring.material.color.set(d.accent);
  layoutCamera();
}
function layoutCamera(){
  const portrait = innerHeight > innerWidth*0.9;
  camera.fov = portrait ? 42 : 30; camera.updateProjectionMatrix();
  const r = robots[selected]; const fx = r ? r.home.x*0.55 : 0;
  // في العرض الأفقيّ تشغل اللوحةُ اليمين، فنُزيح مركز المشهد إلى اليسار
  camRig.goalT.set(fx*0.4 + (portrait ? 0 : 2.7), portrait ? -1.9 : 1.6, portrait ? 2.5 : 0.4);
  camRig.goalP.set(fx*0.5 + (portrait ? 0 : 1.4), portrait ? 3.4 : 2.0, portrait ? 15 : 12.5);
}

// ---------- UI ----------
function buildUI(){
  const chips = document.getElementById('chips');
  ROBOTS.forEach((d,i)=>{ const b=document.createElement('button'); b.className='chip'; b.type='button'; b.innerHTML=`<i style="background:#${d.accent.toString(16).padStart(6,'0')}"></i><span>${d.name}</span>`; b.onclick=()=>select(i); chips.appendChild(b); });
  const pv = document.getElementById('preview');
  PREVIEW.forEach(([label, clip])=>{ const b=document.createElement('button'); b.className='pv'; b.type='button'; b.textContent=label; b.onclick=()=>{ if(selected>=0) play(robots[selected], clip, clip!=='Running'); }; pv.appendChild(b); });
  const name = document.getElementById('name'), go = document.getElementById('go'), err = document.getElementById('err');
  try { const saved = JSON.parse(localStorage.getItem('zakat.player')||'null'); if(saved){ name.value = saved.name||''; } } catch(e){}
  go.onclick = () => {
    const v = name.value.trim();
    if (v.length < 2){ err.textContent = 'اكتب اسمك أوّلًا (حرفان على الأقلّ)'; name.focus(); return; }
    err.textContent = '';
    const d = ROBOTS[selected];
    try { localStorage.setItem('zakat.player', JSON.stringify({ name:v, robot:d.id, model:d.model, accent:d.accent, body:d.body, joints:d.joints, at:Date.now() })); } catch(e){}
    if (selected>=0) play(robots[selected], 'Victory', true);
    document.getElementById('panel').classList.add('leaving');
    setTimeout(()=>{ if (window.__ARTIFACT){ const o=document.getElementById('done'); if(o){ o.querySelector('b').textContent = v; o.hidden = false; } } else location.href = 'game.html'; }, 1400);
  };
  name.addEventListener('keydown', e => { if(e.key==='Enter') go.click(); });
}

// ---------- boot ----------
(async () => {
  const [env, ...rest] = await Promise.all([
    loadSkyHDR(),
    loadGLB(A('models/palm_a.glb')), loadGLB(A('models/palm_b.glb')),
    ...CLIPS.map(c => loadGLB(A('anim/'+c+'.glb'))),
  ]);
  env.mapping = THREE.EquirectangularReflectionMapping; scene.environment = env; scene.background = env; scene.backgroundBlurriness = 0.0; scene.backgroundIntensity = 1.0; scene.environmentIntensity = 0.7; scene.backgroundRotation.set(0, SKY_ROT, 0); scene.environmentRotation.set(0, SKY_ROT, 0);
  scene.fog = new THREE.FogExp2(0xd39a72, 0.0045);
  const T = {
    sandD: loadTex(A('tex/coast_sand_01_diff_1k.jpg'), true, 40), sandN: loadTex(A('tex/coast_sand_01_nor_gl_1k.jpg'), false, 40), sandA: loadTex(A('tex/coast_sand_01_arm_1k.jpg'), false, 40), waterN: loadTex(A('tex/coast_sand_01_nor_gl_1k.jpg'), false, 14),
    pavD: loadTex(A('tex/red_sandstone_pavement_diff_1k.jpg'), true, 3), pavN: loadTex(A('tex/red_sandstone_pavement_nor_gl_1k.jpg'), false, 3), pavA: loadTex(A('tex/red_sandstone_pavement_arm_1k.jpg'), false, 3),
    palmA: rest[0].scene, palmB: rest[1].scene,
  };
  CLIPS.forEach((c, i) => { clips[c] = rest[2+i].animations[0]; clips[c].name = c; });
  buildWorld(T);
  await buildRobots();
  robots.forEach((r,i)=>{ play(r,'Idle'); r.mixer.update(i*0.7); });
  buildUI(); resize(); select(0);
  // لا نُخفي شاشة التحميل حتى تكتمل خاماتُ الأرض والمنصّة أيضًا
  await new Promise(res => { if (manager.isLoading === false && !manager.itemsLoaded) return res(); manager.onLoad = res; setTimeout(res, 8000); });
  renderer.compile(scene, camera);
  loader.classList.add('hide'); document.getElementById('panel').classList.add('in');
  const clock = new THREE.Clock(); let t = 0;
  renderer.setAnimationLoop(() => {
    const dt = Math.min(clock.getDelta(), 0.05); t += dt;
    robots.forEach((r, i) => {
      r.mixer.update(dt);
      if (r.goalPos){ r.pivot.position.lerp(r.goalPos, 1-Math.exp(-dt*4)); r.pivot.rotation.y += (r.goalRot - r.pivot.rotation.y)*(1-Math.exp(-dt*4)); }
      const on = i===selected; r.glow.material.opacity += ((on?0.55:0) - r.glow.material.opacity)*(1-Math.exp(-dt*3));
      if (on) r.glow.scale.setScalar(1+Math.sin(t*2.2)*0.06);
    });
    camRig.target.lerp(camRig.goalT, 1-Math.exp(-dt*2.5)); camRig.pos.lerp(camRig.goalP, 1-Math.exp(-dt*2.5));
    camera.position.set(camRig.pos.x + Math.sin(t*0.25)*0.35, camRig.pos.y + Math.sin(t*0.4)*0.08, camRig.pos.z); camera.lookAt(camRig.target);
    const w = world.userData.water; w.material.normalMap.offset.set(t*0.01, t*0.006);
    world.userData.dust.rotation.y = t*0.02; world.userData.dust.position.y = Math.sin(t*0.5)*0.15;
    world.userData.ring.material.color.offsetHSL(0,0,0); world.userData.ring.scale.setScalar(1+Math.sin(t*1.5)*0.004);
    composer.render();
  });
  window.__ready = 1;
})().catch(e => { console.error(e); document.getElementById('ltext').textContent = 'تعذّر التحميل: ' + e.message; });
